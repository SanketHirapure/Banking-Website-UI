// Assuming this is Dashboard.js in the components folder

import React from 'react';

const Dashboard = () => {
  return (
    <div>
    
    </div>
  );
};

export default Dashboard;
