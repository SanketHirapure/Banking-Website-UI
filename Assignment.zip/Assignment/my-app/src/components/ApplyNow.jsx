import React from 'react';
import styled from 'styled-components';

const ApplyNowContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 20vh; /* Adjust this value as needed */
`;

const ApplyNow = () => {
  return (
    <ApplyNowContainer>
      <h1>Applied</h1>
      
    </ApplyNowContainer>
  );
};

export default ApplyNow;
