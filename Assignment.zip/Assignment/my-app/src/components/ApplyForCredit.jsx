import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const ApplyForCreditContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 30vh; /* Adjust this value as needed */
`;

function ApplyForCredit() {
  return (
    <ApplyForCreditContainer>
      <h2>Apply for Credit</h2>
      <p><strong>Stock Up Easily with Easy Loan Process</strong></p>
      <p>
        Expand your business easily and grow with our easily available loans at the lowest available interest.
      </p>
      <ul>
        <li>Same Day Approval</li>
        <li>Completely Online</li>
        <li>Easy Repayments</li>
      </ul>
      <p>No more waiting to start your business. Your search for Credit ends with us.</p>

      <Link to="/ApplyNow">
        <button>Apply Now </button>
      </Link>
    </ApplyForCreditContainer>
  );
}

export default ApplyForCredit;
