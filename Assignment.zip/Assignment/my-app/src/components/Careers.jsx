import React from 'react';

const Careers = () => {
  return (
    <div>
      
      
    </div>
  );
};

export default Careers;
