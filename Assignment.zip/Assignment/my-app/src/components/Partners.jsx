import React from 'react';

const Partners = () => {
  return (
    <div>
      
    </div>
  );
};

export default Partners;
