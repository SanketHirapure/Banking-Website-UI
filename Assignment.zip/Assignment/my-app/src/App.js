import React from 'react';
import styled from 'styled-components';
import { BrowserRouter as Router, Route, Routes, NavLink } from 'react-router-dom';
import { Link } from 'react-router-dom';
import Home from './components/Home';
import Partners from './components/Partners';
import AboutUs from './components/AboutUs';
import Careers from './components/Careers';
import Blogs from './components/Blogs';
import ContactUs from './components/ContactUs';
import Dashboard from './components/Dashboard';
import ApplyForCredit from './components/ApplyForCredit';
import ApplyNow from './components/ApplyNow';


const PageContainer = styled.div`
  width: 1499px;
  height: 635px ;
  margin: 6px auto;
  border: 1px solid #000000;
  color :white;
  padding: 20px;
  background-color: #4B79FD;
`;

const Container = styled.div`
width: 450px;
height: 200px;
margin: 30px;
padding: 20px;
border-radius: 6px;
top: 20px;
left: 100px;
position : relative;
background-color: #4B79FD;
`;

const Navbar = styled.div`
background-color: #4B79FD;
  color: white;
  display: flex;
  justify-content: space-between;
`;

const NavItemContainer = styled.div`
display: flex;
justify-content: space-between;
padding: 10px;
color : white;
`;


const NavItem = styled.div`
  margin: 0 10px;
  cursor: pointer;
  color: white;
`;

function App() {
  return (
   
    <Router>

    <PageContainer>
    <div> 
     <b> <strong> Credit Bank </strong> </b>
      </div>
        
      <Navbar>
  
  <Container>
        <h2>Empowering SMEs by Easy Access to Credit  $</h2>
        <p>
          We help SMEs take credit easily for their business so that
          they grow and remain sustainable
        </p>

        <Link to="/ApplyforCredit">
    <button>Apply for Credit</button>
  </Link>

      </Container>

  <NavItemContainer>
  <NavItem><Link to="/">Home</Link></NavItem>
     <NavItem><Link to="/partners">Partners</Link></NavItem>
     <NavItem><Link to="/about-us">About Us</Link></NavItem>
            <NavItem><Link to="/careers">Careers</Link></NavItem>
            <NavItem><Link to="/blogs">Blogs</Link></NavItem>
            <NavItem><Link to="/contact-us">Contact Us</Link></NavItem>
            <NavLink to="/dashboard">Dashboard</NavLink>
  </NavItemContainer>
</Navbar>
      <Routes>
          
<Route path="/" element={<Home />} />
          <Route path="/partners" element={<Partners />} />
          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/careers" element={<Careers />} />
          <Route path="/blogs" element={<Blogs />} />
          <Route path="/contact-us" element={<ContactUs />} />
          <Route path="/dashboard" element={<Dashboard />} />
    <Route path="/applyforcredit" element={<ApplyForCredit />} />
    <Route path="/applynow" element={<ApplyNow/>} />
        </Routes>
      
    </PageContainer>
    
    </Router>
  );
}

export default App;
